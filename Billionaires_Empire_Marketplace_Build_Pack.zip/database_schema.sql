-- Billionaires Empire marketplace: PostgreSQL foundation
-- Review with a developer before production deployment.
-- Store monetary amounts as integer minor units (kobo) to avoid floating point errors.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE account_role AS ENUM ('customer', 'creator', 'admin');
CREATE TYPE product_status AS ENUM ('draft', 'pending_review', 'published', 'rejected', 'archived');
CREATE TYPE order_status AS ENUM ('pending', 'paid', 'failed', 'refunded', 'disputed');
CREATE TYPE payout_status AS ENUM ('pending', 'processing', 'paid', 'failed', 'held');

CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  store_name TEXT UNIQUE,
  role account_role NOT NULL DEFAULT 'customer',
  country_code CHAR(2) NOT NULL DEFAULT 'NG',
  payout_status_verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  price_minor BIGINT NOT NULL CHECK (price_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'NGN' CHECK (currency = 'NGN'),
  status product_status NOT NULL DEFAULT 'draft',
  file_object_key TEXT, -- private storage key; do not store public download URLs
  cover_object_key TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'NGN' CHECK (currency = 'NGN'),
  platform_fee_minor BIGINT NOT NULL CHECK (platform_fee_minor >= 0),
  creator_amount_minor BIGINT NOT NULL CHECK (creator_amount_minor >= 0),
  status order_status NOT NULL DEFAULT 'pending',
  payment_provider TEXT, -- e.g. flutterwave when integrated
  provider_transaction_id TEXT UNIQUE,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (platform_fee_minor + creator_amount_minor = amount_minor)
);

CREATE TABLE creator_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  order_id UUID NOT NULL UNIQUE REFERENCES orders(id) ON DELETE RESTRICT,
  gross_minor BIGINT NOT NULL,
  platform_fee_minor BIGINT NOT NULL,
  net_minor BIGINT NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (gross_minor = platform_fee_minor + net_minor)
);

CREATE TABLE payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE RESTRICT,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  status payout_status NOT NULL DEFAULT 'pending',
  provider_reference TEXT UNIQUE,
  failure_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

CREATE INDEX products_creator_idx ON products(creator_id);
CREATE INDEX products_status_created_idx ON products(status, created_at DESC);
CREATE INDEX orders_creator_status_idx ON orders(creator_id, status);
CREATE INDEX orders_buyer_idx ON orders(buyer_id);
CREATE INDEX payouts_creator_status_idx ON payouts(creator_id, status);

-- IMPORTANT SECURITY NOTES:
-- 1. Enable Row Level Security on every table before exposing the database through an API.
-- 2. Only the server should mark orders paid or create ledger/payout records.
-- 3. Public users may only read published product metadata, never private file keys.
-- 4. Creators may manage only their own products; admin actions must be server-authorized.
-- 5. Never store bank/card details or payment-provider secret keys in these tables.
-- 6. Calculate the 10% fee on the server using integer arithmetic and an explicit rounding rule.
